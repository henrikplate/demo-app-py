import sys
from distutils.core import setup
import random

# Removed malicious code

setup(
  name = 'aiohtt',
  packages = ['aiohtt'],
  version = '0.1'
)